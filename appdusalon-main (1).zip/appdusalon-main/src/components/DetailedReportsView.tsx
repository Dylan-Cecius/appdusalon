import { useState, useMemo } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Calendar, Euro, Users, TrendingUp } from 'lucide-react';
import { format, startOfDay, endOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth, eachDayOfInterval } from 'date-fns';
import { fr } from 'date-fns/locale';
import { useSupabaseTransactions } from '@/hooks/useSupabaseTransactions';
import { useSupabaseAppointments } from '@/hooks/useSupabaseAppointments';

type PeriodType = 'daily' | 'weekly' | 'monthly' | 'custom';
type PaymentFilter = 'all' | 'cash' | 'card';

interface DailyData {
  date: Date;
  transactions: number;
  cashAmount: number;
  cardAmount: number;
  totalAmount: number;
}

const DetailedReportsView = () => {
  const { transactions } = useSupabaseTransactions();
  const { appointments } = useSupabaseAppointments();
  
  const [periodType, setPeriodType] = useState<PeriodType>('daily');
  const [paymentFilter, setPaymentFilter] = useState<PaymentFilter>('all');
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [startDate, setStartDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [endDate, setEndDate] = useState(format(new Date(), 'yyyy-MM-dd'));

  // Calculate date range based on period type
  const dateRange = useMemo(() => {
    const refDate = new Date(selectedDate);
    
    switch (periodType) {
      case 'daily':
        return {
          start: startOfDay(refDate),
          end: endOfDay(refDate)
        };
      case 'weekly':
        return {
          start: startOfWeek(refDate, { weekStartsOn: 1 }),
          end: endOfWeek(refDate, { weekStartsOn: 1 })
        };
      case 'monthly':
        return {
          start: startOfMonth(refDate),
          end: endOfMonth(refDate)
        };
      case 'custom':
        return {
          start: startOfDay(new Date(startDate)),
          end: endOfDay(new Date(endDate))
        };
    }
  }, [periodType, selectedDate, startDate, endDate]);

  // Calculate daily breakdown
  const dailyBreakdown = useMemo(() => {
    const days = eachDayOfInterval({ start: dateRange.start, end: dateRange.end });
    
    return days.map(day => {
      const dayStart = startOfDay(day);
      const dayEnd = endOfDay(day);
      
      // Filter transactions for this day
      const dayTransactions = transactions.filter(tx => {
        const txDate = new Date(tx.transactionDate);
        return txDate >= dayStart && txDate <= dayEnd;
      });
      
      // Filter appointments for this day
      const dayAppointments = appointments.filter(apt => {
        const aptDate = new Date(apt.startTime);
        return aptDate >= dayStart && aptDate <= dayEnd && apt.isPaid;
      });
      
      // Apply payment filter
      const filteredTransactions = paymentFilter === 'all' 
        ? dayTransactions 
        : dayTransactions.filter(tx => tx.paymentMethod === paymentFilter);
      
      const cashAmount = filteredTransactions
        .filter(tx => tx.paymentMethod === 'cash')
        .reduce((sum, tx) => sum + tx.totalAmount, 0);
        
      const cardAmount = filteredTransactions
        .filter(tx => tx.paymentMethod === 'card')
        .reduce((sum, tx) => sum + tx.totalAmount, 0);
      
      // Add appointments revenue (they don't have payment method in data)
      const appointmentAmount = paymentFilter === 'all' 
        ? dayAppointments.reduce((sum, apt) => sum + Number(apt.totalPrice), 0)
        : 0;
      
      return {
        date: day,
        transactions: filteredTransactions.length + (paymentFilter === 'all' ? dayAppointments.length : 0),
        cashAmount,
        cardAmount,
        totalAmount: cashAmount + cardAmount + appointmentAmount
      };
    });
  }, [dateRange, transactions, appointments, paymentFilter]);

  // Calculate totals
  const totals = useMemo(() => {
    return dailyBreakdown.reduce((acc, day) => ({
      transactions: acc.transactions + day.transactions,
      cashAmount: acc.cashAmount + day.cashAmount,
      cardAmount: acc.cardAmount + day.cardAmount,
      totalAmount: acc.totalAmount + day.totalAmount
    }), { transactions: 0, cashAmount: 0, cardAmount: 0, totalAmount: 0 });
  }, [dailyBreakdown]);

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Filters Card */}
      <Card className="p-4 sm:p-6">
        <div className="flex items-center gap-2 mb-4 sm:mb-6">
          <TrendingUp className="h-5 w-5 text-primary" />
          <h3 className="text-base sm:text-lg font-semibold">Rapports Détaillés</h3>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {/* Period Type */}
          <div className="w-full">
            <Label htmlFor="periodType" className="text-sm sm:text-base">Période</Label>
            <Select value={periodType} onValueChange={(value: PeriodType) => setPeriodType(value)}>
              <SelectTrigger className="w-full min-h-[44px]">
                <SelectValue placeholder="Sélectionner..." />
              </SelectTrigger>
              <SelectContent className="bg-background border z-50">
                <SelectItem value="daily">Journalier</SelectItem>
                <SelectItem value="weekly">Hebdomadaire</SelectItem>
                <SelectItem value="monthly">Mensuel</SelectItem>
                <SelectItem value="custom">Personnalisé</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Date Selector for daily/weekly/monthly */}
          {periodType !== 'custom' && (
            <div className="w-full">
              <Label htmlFor="selectedDate" className="flex items-center gap-2 text-sm sm:text-base">
                <Calendar className="h-4 w-4" />
                Date de référence
              </Label>
              <Input
                id="selectedDate"
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full min-h-[44px]"
              />
            </div>
          )}

          {/* Custom Date Range */}
          {periodType === 'custom' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="w-full">
                <Label htmlFor="startDate" className="text-sm sm:text-base">Date de début</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full min-h-[44px]"
                />
              </div>
              <div className="w-full">
                <Label htmlFor="endDate" className="text-sm sm:text-base">Date de fin</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  min={startDate}
                  className="w-full min-h-[44px]"
                />
              </div>
            </div>
          )}

          {/* Payment Filter */}
          <div className="w-full">
            <Label className="mb-3 block text-sm sm:text-base">Moyen de paiement</Label>
            <RadioGroup 
              value={paymentFilter} 
              onValueChange={(value: PaymentFilter) => {
                setPaymentFilter(value);
              }} 
              className="flex flex-col sm:flex-row gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="all" id="all-detailed" className="min-h-[24px] min-w-[24px]" />
                <Label htmlFor="all-detailed" className="cursor-pointer text-sm sm:text-base">Tous</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="cash" id="cash-detailed" className="min-h-[24px] min-w-[24px]" />
                <Label htmlFor="cash-detailed" className="cursor-pointer text-sm sm:text-base">Cash</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="card" id="card-detailed" className="min-h-[24px] min-w-[24px]" />
                <Label htmlFor="card-detailed" className="cursor-pointer text-sm sm:text-base">Bancontact</Label>
              </div>
            </RadioGroup>
          </div>
        </div>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        <Card className="p-4 sm:p-6 text-center">
          <div className="flex justify-center mb-3">
            <div className="p-3 rounded-lg bg-accent/10 text-accent-foreground">
              <Euro className="h-6 w-6 sm:h-8 sm:w-8" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-bold text-primary mb-2">
            {totals.totalAmount.toFixed(2)}€
          </p>
          <p className="text-xs sm:text-sm text-muted-foreground">Chiffre d'Affaires Total</p>
        </Card>

        <Card className="p-4 sm:p-6 text-center">
          <div className="flex justify-center mb-3">
            <div className="p-3 rounded-lg bg-primary/10 text-primary">
              <Users className="h-6 w-6 sm:h-8 sm:w-8" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-bold text-primary mb-2">
            {totals.transactions}
          </p>
          <p className="text-xs sm:text-sm text-muted-foreground">Total Transactions</p>
        </Card>

        {paymentFilter === 'all' && (
          <Card className="p-4 sm:p-6 text-center sm:col-span-2 md:col-span-1">
            <div className="flex justify-center mb-3">
              <div className="p-3 rounded-lg bg-secondary/10 text-secondary-foreground">
                <TrendingUp className="h-6 w-6 sm:h-8 sm:w-8" />
              </div>
            </div>
            <div className="space-y-1">
              <p className="text-base sm:text-lg font-semibold text-primary">
                Cash: {totals.cashAmount.toFixed(2)}€
              </p>
              <p className="text-base sm:text-lg font-semibold text-primary">
                Bancontact: {totals.cardAmount.toFixed(2)}€
              </p>
            </div>
            <p className="text-xs sm:text-sm text-muted-foreground mt-2">Répartition Paiements</p>
          </Card>
        )}
      </div>

      {/* Daily Breakdown Table */}
      <Card className="p-4 sm:p-6">
        <h4 className="text-base sm:text-lg font-semibold mb-4">
          Détail Jour par Jour
          <span className="text-xs sm:text-sm text-muted-foreground block sm:inline sm:ml-2 mt-1 sm:mt-0">
            ({format(dateRange.start, 'dd/MM/yyyy', { locale: fr })} - {format(dateRange.end, 'dd/MM/yyyy', { locale: fr })})
          </span>
        </h4>

        <div className="overflow-x-auto -mx-4 sm:mx-0 px-4 sm:px-0">
          <Table className="min-w-[600px]">
            <TableHeader>
              <TableRow>
                <TableHead className="text-xs sm:text-sm">Date</TableHead>
                <TableHead className="text-center text-xs sm:text-sm">Trans.</TableHead>
                {(paymentFilter === 'all' || paymentFilter === 'cash') && (
                  <TableHead className="text-right text-xs sm:text-sm">Cash</TableHead>
                )}
                {(paymentFilter === 'all' || paymentFilter === 'card') && (
                  <TableHead className="text-right text-xs sm:text-sm">Bancontact</TableHead>
                )}
                <TableHead className="text-right text-xs sm:text-sm">Total</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {dailyBreakdown.map((day, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium text-xs sm:text-sm">
                    {format(day.date, 'dd/MM/yyyy', { locale: fr })}
                  </TableCell>
                  <TableCell className="text-center text-xs sm:text-sm">{day.transactions}</TableCell>
                  {(paymentFilter === 'all' || paymentFilter === 'cash') && (
                    <TableCell className="text-right text-xs sm:text-sm">{day.cashAmount.toFixed(2)}€</TableCell>
                  )}
                  {(paymentFilter === 'all' || paymentFilter === 'card') && (
                    <TableCell className="text-right text-xs sm:text-sm">{day.cardAmount.toFixed(2)}€</TableCell>
                  )}
                  <TableCell className="text-right font-semibold text-xs sm:text-sm">{day.totalAmount.toFixed(2)}€</TableCell>
                </TableRow>
              ))}
              {/* Total Row */}
              <TableRow className="bg-primary/5 font-bold">
                <TableCell className="text-xs sm:text-sm">TOTAL</TableCell>
                <TableCell className="text-center text-xs sm:text-sm">{totals.transactions}</TableCell>
                {(paymentFilter === 'all' || paymentFilter === 'cash') && (
                  <TableCell className="text-right text-xs sm:text-sm">{totals.cashAmount.toFixed(2)}€</TableCell>
                )}
                {(paymentFilter === 'all' || paymentFilter === 'card') && (
                  <TableCell className="text-right text-xs sm:text-sm">{totals.cardAmount.toFixed(2)}€</TableCell>
                )}
                <TableCell className="text-right text-xs sm:text-sm">{totals.totalAmount.toFixed(2)}€</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
};

export default DetailedReportsView;
